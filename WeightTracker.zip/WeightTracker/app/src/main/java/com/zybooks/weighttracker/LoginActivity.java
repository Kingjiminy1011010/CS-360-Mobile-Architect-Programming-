package com.zybooks.weighttracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * This class handles user login and registration.
 * It allows users to create a new account with a username, password, and a goal weight,
 * or log in to an existing account.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText, goalWeightEditText;
    private Button loginButton, registerButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Initialize the DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Set up onClick listener for the Login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                Cursor cursor = databaseHelper.checkUser(username, password);

                if (cursor.moveToFirst()) {
                    long userId = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_USER_ID));
                    double goalWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GOAL_WEIGHT));

                    // Start MainActivity and pass user ID and goal weight
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.putExtra("USER_ID", userId);
                    intent.putExtra("GOAL_WEIGHT", goalWeight);
                    startActivity(intent);
                    finish(); // Close LoginActivity
                } else {
                    Toast.makeText(LoginActivity.this, "Login failed. Invalid username or password.", Toast.LENGTH_SHORT).show();
                }
                cursor.close();
            }
        });

        // Set up onClick listener for the Register button
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String goalWeightString = goalWeightEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty() || goalWeightString.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    double goalWeightLbs = Double.parseDouble(goalWeightString);
                    // Convert the goal weight from pounds (lbs) to kilograms (kg)
                    double goalWeightKg = goalWeightLbs / 2.20462;

                    boolean isAdded = databaseHelper.addUser(username, password, goalWeightKg);
                    if (isAdded) {
                        Toast.makeText(LoginActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                        // Automatically log the user in after successful registration
                        loginButton.performClick();
                    } else {
                        Toast.makeText(LoginActivity.this, "Registration failed. Username may already exist.", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(LoginActivity.this, "Invalid goal weight format.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}