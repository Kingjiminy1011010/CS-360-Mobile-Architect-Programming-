package com.zybooks.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This class handles all the database operations for the weight tracker app,
 * including creating tables, adding users, and managing weight entries.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database information
    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 2; // Updated to version 2 for new features

    // Users table and columns
    private static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "_id"; // Added to satisfy SimpleCursorAdapter requirements
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    public static final String COL_GOAL_WEIGHT = "goal_weight";

    // Weight Entries table and columns
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String COL_ENTRY_ID = "_id"; // Added to satisfy SimpleCursorAdapter requirements
    private static final String COL_USER_ID_FK = "user_id";
    public static final String COL_ENTRY_WEIGHT = "weight";
    public static final String COL_ENTRY_DATE = "date";

    // SQL query to create the users table
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_USERNAME + " TEXT UNIQUE, " +
            COL_PASSWORD + " TEXT, " +
            COL_GOAL_WEIGHT + " REAL" +
            ");";

    // SQL query to create the weight entries table
    private static final String CREATE_WEIGHT_ENTRIES_TABLE = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + " (" +
            COL_ENTRY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_USER_ID_FK + " INTEGER, " +
            COL_ENTRY_WEIGHT + " REAL, " +
            COL_ENTRY_DATE + " TEXT, " +
            "FOREIGN KEY(" + COL_USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + ")" +
            ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Execute the create table queries
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHT_ENTRIES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they exist and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    /**
     * Adds a new user to the database.
     *
     * @param username   The user's chosen username.
     * @param password   The user's chosen password.
     * @param goalWeight The user's goal weight.
     * @return true if the user was added successfully, false otherwise.
     */
    public boolean addUser(String username, String password, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        contentValues.put(COL_GOAL_WEIGHT, goalWeight);

        long result = db.insert(TABLE_USERS, null, contentValues);
        db.close();

        // If the insert operation failed, insert() returns -1
        return result != -1;
    }

    /**
     * Checks if a user with the given username and password exists.
     *
     * @param username The username to check.
     * @param password The password to check.
     * @return A Cursor with the user's data if found, or an empty cursor.
     */
    public Cursor checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL_USER_ID, COL_USERNAME, COL_GOAL_WEIGHT};
        String selection = COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        return cursor;
    }

    /**
     * Adds a new weight entry for a specific user.
     *
     * @param userId The ID of the user.
     * @param weight The weight value to be added.
     * @param date   The date of the entry.
     * @return true if the entry was added successfully, false otherwise.
     */
    public boolean addWeightEntry(long userId, double weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USER_ID_FK, userId);
        contentValues.put(COL_ENTRY_WEIGHT, weight);
        contentValues.put(COL_ENTRY_DATE, date);

        long result = db.insert(TABLE_WEIGHT_ENTRIES, null, contentValues);
        db.close();
        return result != -1;
    }

    /**
     * Retrieves all weight entries for a given user, ordered by date.
     *
     * @param userId The ID of the user.
     * @return A Cursor with the weight entries.
     */
    public Cursor getWeightEntries(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL_ENTRY_ID, COL_ENTRY_WEIGHT, COL_ENTRY_DATE};
        String selection = COL_USER_ID_FK + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        String orderBy = COL_ENTRY_DATE + " DESC, " + COL_ENTRY_ID + " DESC"; // Order by date descending, then ID to get latest entry

        Cursor cursor = db.query(TABLE_WEIGHT_ENTRIES, columns, selection, selectionArgs, null, null, orderBy);
        return cursor;
    }
}