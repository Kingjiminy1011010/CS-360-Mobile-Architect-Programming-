package com.zybooks.weighttracker;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

/**
 * This activity displays a list of all weight entries for the current user.
 * It retrieves the data from the SQLite database and populates a ListView.
 */
public class HistoryActivity extends AppCompatActivity {

    private ListView historyListView;
    private TextView emptyTextView;
    private DatabaseHelper databaseHelper;
    private long currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Initialize UI elements
        historyListView = findViewById(R.id.historyListView);
        emptyTextView = findViewById(R.id.emptyTextView);

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(this);

        // Get the user ID from the intent passed from MainActivity
        currentUserId = getIntent().getLongExtra("USER_ID", -1);

        if (currentUserId == -1) {
            // Handle the case where the user ID was not passed correctly
            Toast.makeText(this, "User data not found.", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
        } else {
            // Load and display the weight history
            loadWeightHistory();
        }
    }

    /**
     * Retrieves all weight entries for the current user from the database
     * and populates the ListView.
     */
    private void loadWeightHistory() {
        // Get the cursor containing all weight entries for the user
        Cursor cursor = databaseHelper.getWeightEntries(currentUserId);

        // Check if the cursor is empty
        if (cursor.getCount() == 0) {
            emptyTextView.setVisibility(TextView.VISIBLE);
            historyListView.setVisibility(ListView.GONE);
            cursor.close();
            return;
        }

        emptyTextView.setVisibility(TextView.GONE);
        historyListView.setVisibility(ListView.VISIBLE);

        // Define which columns from the database will be displayed
        String[] fromColumns = {
                DatabaseHelper.COL_ENTRY_WEIGHT,
                DatabaseHelper.COL_ENTRY_DATE
        };

        // Define which TextViews in the list item layout will display the data
        int[] toViews = {
                R.id.weightTextView,
                R.id.dateTextView
        };

        // Create a SimpleCursorAdapter to bind the data to the ListView
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_item_weight,
                cursor,
                fromColumns,
                toViews,
                0 // no flags
        );

        // Override the setViewBinder to format the weight
        adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
            @Override
            public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                if (columnIndex == cursor.getColumnIndex(DatabaseHelper.COL_ENTRY_WEIGHT)) {
                    double weightKg = cursor.getDouble(columnIndex);
                    double weightLbs = weightKg * 2.20462;
                    ((TextView) view).setText(String.format(Locale.getDefault(), "Weight: %.1f lbs", weightLbs));
                    return true;
                }
                // Return false for other columns to use the default binding
                return false;
            }
        });

        // Set the adapter for the ListView
        historyListView.setAdapter(adapter);
    }
}
