package com.zybooks.weighttracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * The MainActivity serves as the main dashboard for the user.
 * It displays the user's current and goal weight, and allows them
 * to add new weight entries and navigate to the history screen.
 */
public class MainActivity extends AppCompatActivity {

    // Member variables for UI elements
    private TextView welcomeTextView, currentWeightTextView, goalWeightTextView;
    private Button addEntryButton, viewHistoryButton;
    private DatabaseHelper databaseHelper;

    // Variables for user data
    private long currentUserId;
    private double userGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        welcomeTextView = findViewById(R.id.welcomeTextView);
        currentWeightTextView = findViewById(R.id.currentWeightTextView);
        goalWeightTextView = findViewById(R.id.goalWeightTextView);
        addEntryButton = findViewById(R.id.addEntryButton);
        viewHistoryButton = findViewById(R.id.viewHistoryButton);

        // Initialize the DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Get user data from the Intent (passed from LoginActivity)
        Intent intent = getIntent();
        if (intent != null) {
            currentUserId = intent.getLongExtra("USER_ID", -1);
            userGoalWeight = intent.getDoubleExtra("GOAL_WEIGHT", 0.0);
        }

        // Set the user's welcome message and goal weight
        welcomeTextView.setText("Welcome User!");
        double goalWeightLbs = userGoalWeight * 2.20462;
        goalWeightTextView.setText(String.format(Locale.getDefault(), "%.1f lbs", goalWeightLbs));

        // Load and display the most recent weight entry
        loadLatestWeight();

        // Set up onClick listener for the Add Entry button
        addEntryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddEntryDialog();
            }
        });

        // Set up onClick listener for the View History button
        viewHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the HistoryActivity and pass the user ID
                Intent historyIntent = new Intent(MainActivity.this, HistoryActivity.class);
                historyIntent.putExtra("USER_ID", currentUserId);
                startActivity(historyIntent);
            }
        });
    }

    /**
     * Loads the latest weight entry from the database for the current user
     * and updates the UI.
     */
    private void loadLatestWeight() {
        Cursor cursor = databaseHelper.getWeightEntries(currentUserId);
        if (cursor.moveToFirst()) {
            double latestWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ENTRY_WEIGHT));
            double latestWeightLbs = latestWeight * 2.20462;
            currentWeightTextView.setText(String.format(Locale.getDefault(), "%.1f lbs", latestWeightLbs));
        } else {
            currentWeightTextView.setText("-- lbs"); // No entries found
        }
        cursor.close();
    }

    /**
     * Displays a dialog to the user for adding a new weight entry.
     */
    private void showAddEntryDialog() {
        // Create an AlertDialog with an EditText for weight input
        final EditText weightInput = new EditText(this);
        weightInput.setHint("Enter today's weight (lbs)");
        weightInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        new AlertDialog.Builder(this)
                .setTitle("Add New Weight Entry")
                .setView(weightInput)
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        String weightString = weightInput.getText().toString().trim();
                        if (!weightString.isEmpty()) {
                            try {
                                double newWeightLbs = Double.parseDouble(weightString);
                                double newWeightKg = newWeightLbs / 2.20462; // Convert lbs to kg before saving to DB
                                String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                                // Add the new weight entry to the database
                                boolean isAdded = databaseHelper.addWeightEntry(currentUserId, newWeightKg, currentDate);
                                if (isAdded) {
                                    Toast.makeText(MainActivity.this, "Weight entry added!", Toast.LENGTH_SHORT).show();
                                    loadLatestWeight(); // Refresh the displayed weight
                                } else {
                                    Toast.makeText(MainActivity.this, "Failed to add entry.", Toast.LENGTH_SHORT).show();
                                }
                            } catch (NumberFormatException e) {
                                Toast.makeText(MainActivity.this, "Invalid number format.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
